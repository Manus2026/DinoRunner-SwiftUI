import SwiftUI
import GoogleMobileAds

@main
struct DinoRunnerApp: App {
    init() {
        // 在最新版 SDK 中，start 方法的 completionHandler 是可選的，但需要明確指定類型或傳入 nil
        MobileAds.sharedInstance().start(completionHandler: nil)
    }
    
    var body: some Scene {
        WindowGroup {
            VStack(spacing: 0) {
                ContentView()
                    .preferredColorScheme(nil)
                
                BannerAdView()
                    .frame(height: 50)
                    .background(Color.black.opacity(0.05))
            }
        }
    }
}

struct BannerAdView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = UIViewController()
        // 最新版 SDK 語法：GADBannerView(adSize: AdSizeBanner)
        let bannerView = GADBannerView(adSize: AdSizeBanner)
        
        // 使用使用者提供的廣告單元 ID
        bannerView.adUnitID = "ca-app-pub-2331479066428545/7604889398"
        bannerView.rootViewController = viewController
        viewController.view.addSubview(bannerView)
        
        // 最新版 SDK 語法：GADRequest() 重新命名為 Request()
        let request = GADRequest()
        bannerView.load(request)
        
        return viewController
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}
